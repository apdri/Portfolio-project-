//TODO :Make M+ M- and MC functional.
let string= "";
let buttons= document.querySelectorAll('.button');
Array.from(buttons).forEach((button)=>{
  button.addEventListener('click',(e)=>{
    if(e.target.innerHTML == '='){
      string=eval(string);
      document.querySelector('input').value = string;
    }
    else if(e.target.innerHTML == 'AC'){
        string="";
        document.querySelector('input').value = string;
      }
    else{
    console.log(e.target)
    string=string+e.target.innerHTML;
    document.querySelector('input').value=string;
    }
    function backspace(){
      var display = document.getElementById('display');
      display.value = display.value.slice(0, -1);
    }
    //let memory=0;
    //let currentTotal=0;
    //function addToMemory(){
      //memory+= currentTotal;
    //}
    //function substractFromMemory(){
      //memory-= currentTotal;
    //}
    //function clearMemory(){
      //memory=0;
    //}
    //document.getElementById('mPlusButton').addEventListener('click',addToMemory);
    //document.getElementById('mMinusButton').addEventListener('click',substractFromMemory);
    
  })
})